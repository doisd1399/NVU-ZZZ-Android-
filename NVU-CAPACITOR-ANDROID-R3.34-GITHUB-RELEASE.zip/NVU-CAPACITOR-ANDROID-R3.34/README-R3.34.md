# NVU R3.34

Correção cirúrgica de integridade monetária do fluxo automático GTO.

Versões:
- R3.34
- Android 1.0.51 / versionCode 51
- Web 2.3.9 (inalterado)
- Firebase Functions: alteradas nesta revisão

Principais correções:
- `R$ 5.300,00` não pode mais ser convertido em `R$ 530.000,00`.
- consenso do valor final passa a armazenar evidência em centavos explícitos;
- evidências monetárias ambíguas de releases antigas são descartadas ao atualizar;
- fila local bloqueia valor final incompatível com o valor ofertado;
- Firebase Functions aplica a mesma barreira antes de gravar no Firestore.

Leia também:
- `RELEASE_R3_34_INTEGRIDADE_MONETARIA.md`
- `R3_34_VALIDATION_REPORT.txt`
- `COMANDOS-R3.34-RELEASE-WINDOWS.txt`
