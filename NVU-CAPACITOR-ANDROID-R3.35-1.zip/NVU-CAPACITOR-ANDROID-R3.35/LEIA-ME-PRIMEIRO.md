# NVU — Projeto corrigido para Capacitor + Netlify

Este pacote foi preparado para Windows e usa o registro público oficial do NPM.
As referências internas que causavam `ETIMEDOUT` foram removidas do
`package-lock.json`.

## Requisitos

- Windows 10 ou 11;
- Node.js 22 ou superior;
- Android Studio com Android SDK 36;
- conexão com a internet na primeira instalação;
- JDK 21 (o Android Studio atual normalmente inclui o JBR 21 compatível).

## Forma recomendada no Windows

1. Extraia o ZIP em uma pasta curta, por exemplo:

   `C:\Projetos\NVU-Capacitor-Netlify-Corrigido`

2. Feche outros terminais, VS Code e Android Studio que estejam usando essa
   pasta.
3. Dê dois cliques em `PREPARAR-ANDROID-WINDOWS.bat`.
4. Quando aparecer `[OK] PROJETO PREPARADO COM SUCESSO`, dê dois cliques em
   `ABRIR-ANDROID-STUDIO.bat`.

O preparador executa automaticamente:

- validação do Node.js e dos arquivos obrigatórios;
- configuração do registro `https://registry.npmjs.org/`;
- remoção segura de uma instalação incompleta;
- `npm ci`;
- verificação TypeScript e build das Firebase Functions;
- certificação funcional completa até a R3.35;
- build de produção;
- atualização do fallback web embarcado;
- sincronização do Capacitor com Android.

## Gerar um APK de teste sem usar o menu do Android Studio

Depois de preparar o projeto, dê dois cliques em:

`GERAR-APK-DEBUG-WINDOWS.bat`

Quando concluir, o APK estará em:

`android\app\build\outputs\apk\debug\app-debug.apk`

## Comandos manuais equivalentes

```bat
npm ci
npm --prefix functions ci
npm run lint
npm --prefix functions run build
npm run verify:release
npm run build
npm run prepare:cap-assets
npx cap sync android
npx cap open android
```

## Netlify remoto

O APK está configurado para carregar:

`https://stirring-pavlova-ca6808.netlify.app`

A configuração está em `capacitor.remote.json`.

Com o modo remoto ativo, alterações somente no site entram no aplicativo após o
deploy no Netlify. Mudanças nativas, plugins, permissões, ícone, assinatura ou
configurações Android exigem novo APK/AAB.

A R3.28 mantém a máquina de estados determinística e corrige a causa prática observada
no aparelho: a autorização de MediaProjection não é mais solicitada enquanto a NVU ainda
está em retrato. O GTO é aberto primeiro; somente depois de o pacote real do simulador ser
confirmado em primeiro plano a autorização Android aparece sobre o GTO. A captura começa
com métricas orientadas à rotação e possui fallback limitado para OEMs Android 14+ que não
entregam `onCapturedContentResize`, evitando o estado permanente de 0/3 quadros estáveis.

A tela real enviada no teste (1536x691) permanece como fixture de regressão do detector e
é reconhecida como uma lista de 5 fretes; as cinco linhas são exercitadas individualmente
na regressão de seleção. Sair do GTO pausa a leitura sem alterar o estado, voltar retoma o
mesmo fluxo e telas desconhecidas continuam neutras. O frete confirmado permanece imutável,
o botão mostra `Frete atual em andamento` e a conclusão continua exigindo resultado real +
`Receber` antes de persistir, selar, enfileirar e enviar ao Firebase.

O `Painel Sênior` agora fica visível para qualquer usuário já autenticado dentro do
`AdminLayout`, que é protegido por `allowedRole="admin"`; o conteúdo Sênior continua com
seu próprio gate seguro de senha/custom claim Firebase.

Esta release exige novo APK/AAB Android (`versionName 1.0.45`, `versionCode 45`).
A camada Web também mudou (`2.3.9`), portanto publique o `dist` certificado no Netlify com
`npx netlify-cli deploy --prod --dir=dist --no-build`. Não execute outro build depois do
`PREPARAR-ANDROID-WINDOWS.bat`, pois o preparador já certifica a paridade Web↔Android e
executa uma compilação Java real do módulo Android com JDK 21.

## Firebase Android

O arquivo abaixo está incluído e foi validado para o pacote
`com.nvu.operacional`:

`android\app\google-services.json`

Não substitua esse arquivo por um de outro projeto Firebase.

## Avisos `deprecated`

O NPM pode mostrar avisos de dependências indiretas descontinuadas. Esses avisos
não interrompem a instalação. O erro anterior era o endereço interno presente no
lockfile, e ele foi removido neste pacote.

---

## R3.35 — correções cirúrgicas de perfil, overlay, integridade do frete e Painel Sênior

A R3.35 altera Android (`1.0.52`, versionCode `52`), Web (`2.3.10`) e Firebase Functions.

Principais mudanças: carregamento finito no seletor de perfil/Painel Sênior; início automático com contexto GTO consistente; sessão explícita do overlay para impedir `Reativar` órfão; card flutuante reposicionado sem fechamento automático; mensagens adaptativas/deduplicadas; conflito de grafia do frete bloqueado antes do commit; Empresa do frete exposta como Origem; valor ofertado e valor final usando parser monetário seguro e exibição pt-BR.

Depois do `PREPARAR-ANDROID-WINDOWS.bat`, publique **Firebase Functions e Netlify**:

`set "FUNCTIONS_DISCOVERY_TIMEOUT=60"`

`npx firebase deploy --only functions --project vtc-frota-log`

`npx netlify-cli deploy --prod --dir=dist --no-build`

Não execute outro build entre o PREPARAR e o deploy do `dist`. Depois gere a release Android assinada com a mesma keystore oficial.

---

## R3.34 — correção crítica de integridade monetária

A R3.34 corrige a causa que podia transformar `R$ 5.300,00` em `R$ 530.000,00`. Android e Firebase Functions mudaram; o Web permanece `2.3.9`.

Depois de `PREPARAR-ANDROID-WINDOWS.bat`, publique obrigatoriamente as Functions com:

`set "FUNCTIONS_DISCOVERY_TIMEOUT=60"`

`npx firebase deploy --only functions --project vtc-frota-log`

Não é necessário republicar Netlify somente por esta revisão. Depois gere a release Android assinada com a mesma keystore oficial.

A validação monetária agora preserva centavos e separadores, invalida evidências ambíguas anteriores e bloqueia no APK e no backend valores finais com padrão evidente de corrupção ~100x.

---

## R3.29 — correção estrita da tela de fretes

A R3.29 altera apenas a camada nativa Android do observador GTO. O Web permanece 2.3.9 e as Firebase Functions permanecem compatíveis; não é necessário republicar Netlify/Functions somente por esta correção.

A tela de fretes agora só é aceita quando a geometria completa dos cards `Aceitar` corresponde ao layout real do GTO. Telas de condução, pátio, mapa/menu e outras interfaces permanecem neutras e não podem iniciar OCR nem alterar a etapa da viagem.

Android: `versionName 1.0.46`, `versionCode 46`.

---


## R3.31 — continuidade da viagem e próximo frete

A R3.31 altera somente a camada nativa Android. Durante uma viagem confirmada, pixels semelhantes a botões `Aceitar` são neutros e não podem mais gerar uma falsa lista. A leitura de uma nova lista durante `TRIP_IN_PROGRESS` só é habilitada após o motorista tocar em **Trocar frete atual** no painel flutuante.

Após `Receber`, a conclusão continua sendo persistida e enfileirada antes do envio. Quando o backend confirma o ACK e a operação ainda possui entregas, a NVU informa **“Viagem enviada automaticamente à NVU · pronto para o próximo frete.”** e prepara automaticamente uma nova sessão `WAITING_FREIGHT`, sem exigir reinício do app.

Ao sair rapidamente do GTO, a leitura pausa sem alterar o estado da viagem. Ao retornar, apenas evidências visuais temporárias são descartadas e reconstruídas a partir da tela atual; frete selecionado, snapshot, resultado, Receive latch e fila durável permanecem preservados.

Android: `versionName 1.0.48`, `versionCode 48`. Web: `2.3.9`.

## R3.30 — confirmação robusta do frete selecionado

A R3.30 altera somente a camada nativa Android do observador GTO. O Web permanece `2.3.9` e as Firebase Functions não mudaram; não é necessário republicar Netlify ou Functions somente por esta correção.

A causa raiz observada na R3.29 estava depois da detecção da linha. O aplicativo já encontrava a linha tocada, porém exigia concordância literal completa entre o OCR estabilizado da lista e um segundo OCR recortado da linha. No layout real enviado, `Fábrica de Tijolo > Cooper Log` pode quebrar visualmente em duas linhas. O refinamento do OCR recortado podia encurtar `Cooper Log` para `Cooper`, gerando uma divergência artificial e cancelando um frete válido.

Na R3.30 a seleção da linha continua sendo determinada pela geometria visual/touch do botão `Aceitar`, enquanto os dados persistidos vêm exclusivamente da leitura canônica estabilizada da página, com consenso de múltiplas leituras. O OCR recortado virou uma verificação auxiliar e nunca pode reescrever nomes, empresas ou cidades. Divergência numérica explícita de distância/valor continua bloqueando a confirmação.

Também é forçada uma segunda leitura canônica da página quando o motorista toca rápido demais para a lista já ter atingido o consenso mínimo. O refinamento de rota passou a ser somente de preenchimento e preserva nomes de empresa quebrados em múltiplas linhas.

Android: `versionName 1.0.47`, `versionCode 47`.
