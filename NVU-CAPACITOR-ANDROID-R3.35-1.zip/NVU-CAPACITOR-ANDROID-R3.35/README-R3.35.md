# NVU R3.35

Revisão cirúrgica do fluxo automático GTO, integridade dos dados do frete, ciclo de vida do overlay e carregamento do Painel Sênior.

Versões:
- R3.35
- Android 1.0.52 / versionCode 52
- Web 2.3.10
- Firebase Functions: alteradas nesta revisão

Principais correções:
- seletor de perfil deixa de fabricar o estado textual `Carregando...` como empresa e passa a encerrar o carregamento em sucesso, vazio ou erro recuperável;
- `Iniciar trabalho → Modo automático` usa o mesmo contexto GTO em todos os pontos de entrada e arma explicitamente a sessão do overlay;
- botão NVU/Reativar é condicionado à sessão automática + GTO em foreground; remover a tarefa NVU dos recentes suprime imediatamente overlays órfãos;
- minimizar o GTO preserva a viagem e permite restauração do botão ao retornar;
- card técnico `Automação GTO` fica oculto no Dashboard, mas sua lógica permanece montada em modo headless;
- o card flutuante não fecha mais sozinho por falta de espaço: ele é reposicionado sem cobrir a bolha;
- mensagens escolhem dinamicamente o lado com mais espaço e eventos semânticos repetidos são deduplicados por sessão;
- diferenças críticas de texto entre a leitura canônica e a leitura auxiliar agora falham de forma fechada em vez de persistir uma grafia divergente;
- Empresa do frete é exposta como Origem da entrega, mantendo os campos técnicos de rota separados;
- valores exibidos usam formato pt-BR (`R$ 5.300,00`) e o valor ofertado também passa pelo parser monetário seguro;
- Painel Sênior deixa de permanecer indefinidamente em `Sincronizando` quando a empresa referenciada não resolve.

Publicação desta revisão exige:
1. `PREPARAR-ANDROID-WINDOWS.bat`;
2. Firebase Functions;
3. Netlify com o `dist` produzido pelo PREPARAR, sem novo build depois;
4. APK release assinado com a mesma keystore oficial.

Consulte `COMANDOS-R3.35-RELEASE-WINDOWS.txt` e `R3_35_VALIDATION_REPORT.txt`.
