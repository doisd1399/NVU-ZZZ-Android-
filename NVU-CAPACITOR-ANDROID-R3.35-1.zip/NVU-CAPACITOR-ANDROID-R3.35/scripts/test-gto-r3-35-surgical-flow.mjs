import { spawnSync } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const read = (p) => fs.readFileSync(p, "utf8");
const service = read("android/app/src/main/java/com/nvu/operacional/GtoObserverService.java");
const money = read("android/app/src/main/java/com/nvu/operacional/GtoMoneyValue.java");
const guard = read("android/app/src/main/java/com/nvu/operacional/GtoFreightTextGuard.java");
const sync = read("android/app/src/main/java/com/nvu/operacional/GtoAutoTripSync.java");
const selector = read("src/pages/SelectProfile.tsx");
const observerSetup = read("src/components/GtoObserverSetup.tsx");
const dashboard = read("src/pages/driver/Dashboard.tsx");
const profile = read("src/pages/driver/Profile.tsx");
const companyTab = read("src/pages/admin/fleet/CompanyTab.tsx");
const functions = read("functions/src/gtoTrips.ts");
const gradle = read("android/app/build.gradle");
const pkg = JSON.parse(read("package.json"));

const checks = [];
const check = (name, ok, detail = "") => {
  checks.push({ name, ok: Boolean(ok) });
  console.log(`${ok ? "PASS" : "FAIL"} ${name}${detail ? ` — ${detail}` : ""}`);
};

function runJava(name, mainClass, sources) {
  const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "nvu-r335-"));
  try {
    const run = spawnSync(
      "java",
      ["scripts/java-tests/JavaTestRunner.java", tmp, mainClass, ...sources],
      { encoding: "utf8" },
    );
    const out = `${run.stderr || ""}\n${run.stdout || ""}`.trim();
    check(`${name} fixtures compile`, !out.includes("Java compilation failed"), out);
    check(`${name} scenarios pass`, run.status === 0 && String(run.stdout || "").includes("PASS"), out);
  } finally {
    fs.rmSync(tmp, { recursive: true, force: true });
  }
}

check("R3.35 Android version", gradle.includes("versionCode 52") && gradle.includes('versionName "1.0.52"'));
check("R3.35 Web version", pkg.version === "2.3.10");

check(
  "profile selector never fabricates Carregando as a company name",
  selector.includes("companyById") &&
    selector.includes("unresolvedCompanyIds") &&
    !selector.includes('const cName = comp ? comp.companyName : "Carregando..."'),
);
check(
  "profile selector has finite retry/error path",
  selector.includes("companyCatalogAttempted") &&
    selector.includes("Empresa indisponível") &&
    selector.includes("loadCompanyCatalog(true)"),
);

check(
  "automatic mode keeps observer logic headless instead of rendering diagnostics card",
  observerSetup.includes("headless?: boolean") &&
    observerSetup.includes("if (headless) return null") &&
    dashboard.includes("<GtoObserverSetup\n              headless"),
);
check(
  "both driver entry points send the same automatic GTO route context",
  dashboard.includes("contractMode: contract.mode") &&
    dashboard.includes("currentGtoCity:") &&
    profile.includes("contractMode: activeContract.mode") &&
    profile.includes("currentGtoCity:"),
);

check(
  "explicit automatic launch is the authority that arms overlays",
  service.includes('.putBoolean("automaticOverlaySessionActive", true)') &&
    service.includes('.putBoolean("overlaySuppressedByTaskRemoval", false)'),
);
check(
  "bubble requires real GTO foreground and an active automatic overlay session",
  service.includes('!prefs.getBoolean("automaticOverlaySessionActive", false)') &&
    service.includes('prefs.getBoolean("overlaySuppressedByTaskRemoval", false)') &&
    service.includes("|| !gtoForeground"),
);
check(
  "Reativar is gated by the same automatic-session lifecycle",
  service.includes('&& prefs.getBoolean("automaticOverlaySessionActive", false)') &&
    service.includes('&& !prefs.getBoolean("overlaySuppressedByTaskRemoval", false)') &&
    service.includes("private boolean shouldShowProjectionReauthButton()"),
);
check(
  "removing NVU from recents immediately suppresses and removes overlays",
  service.includes("public void onTaskRemoved(Intent rootIntent)") &&
    service.includes('.putBoolean("automaticOverlaySessionActive", false)') &&
    service.includes('.putBoolean("overlaySuppressedByTaskRemoval", true)') &&
    service.includes("hideOverlays();"),
);

check(
  "menu geometry refresh repositions instead of auto-closing",
  service.includes("positionMenuWithoutCoveringBubble(screen, true)") &&
    service.includes("A geometry refresh must never be interpreted as a request to close"),
);
check(
  "status messages choose space dynamically around bubble/card",
  service.includes("int leftSpace = Math.max(0, bubbleLeft - gap - margin)") &&
    service.includes("int rightSpace = Math.max(0, chipRightLimit - (bubbleRight + gap))") &&
    service.includes("boolean useRight = rightSpace >= leftSpace"),
);
check(
  "semantic driver messages are deduplicated per trip session",
  service.includes("if (key.equals(previousKey) || key.equals(pendingKey)) return;"),
);

check(
  "full-page freight voting preserves visible spelling and accents",
  service.includes("GtoFreightTextGuard.comparisonKey(value)") &&
    !service.includes('? digitsOnly(value) : normalize(value);'),
);
check(
  "independent selected-row text conflicts fail closed",
  service.includes("Duas leituras independentes do frete divergiram") &&
    service.includes("sameOrSafeWholeWordPrefix"),
);
check(
  "selected freight card exposes GTO company as Origem",
  service.includes('details.append("Origem: ")') && !service.includes('details.append("Empresa: ")'),
);
check(
  "sync compatibility origin alias uses GTO freight company",
  sync.includes('payload.put("origem", payload.optString("originCompany", ""))'),
);
check(
  "Firestore history origin uses GTO freight company without destroying route-origin context",
  functions.includes("origem: originCompany") &&
    functions.includes('origemFonte: originCompany ? "GTO_FREIGHT_COMPANY"') &&
    functions.includes("gtoOrigin: origin"),
);

check(
  "offered-value OCR preserves decimal semantics before canonicalization",
  service.includes("return GtoMoneyValue.canonicalNumber(matcher.group(1));"),
);
check(
  "native monetary display uses centralized pt-BR formatter",
  money.includes("static String formatPtBr") &&
    service.includes("GtoMoneyValue.formatPtBr(value)") &&
    service.includes("GtoMoneyValue.formatPtBr(finalGainRaw)"),
);

check(
  "Senior company screen cannot remain in unconditional infinite synchronization",
  companyTab.includes("resolvedCompanyId") &&
    companyTab.includes("companiesLoading || (!companyCatalogLoaded && !companyCatalogAttempted)") &&
    companyTab.includes("Não foi possível carregar a empresa") &&
    companyTab.includes("loadCompanyCatalog(true)"),
);

runJava(
  "literal freight integrity",
  "com.nvu.operacional.GtoFreightDataIntegrityTest",
  [
    "android/app/src/main/java/com/nvu/operacional/GtoFreightTextGuard.java",
    "android/app/src/main/java/com/nvu/operacional/GtoMoneyValue.java",
    "android/app/src/main/java/com/nvu/operacional/GtoResultValueConsensus.java",
    "scripts/java-tests/com/nvu/operacional/GtoFreightDataIntegrityTest.java",
  ],
);
runJava(
  "pt-BR money semantics",
  "com.nvu.operacional.GtoMoneyValueRegressionTest",
  [
    "android/app/src/main/java/com/nvu/operacional/GtoMoneyValue.java",
    "android/app/src/main/java/com/nvu/operacional/GtoResultValueConsensus.java",
    "scripts/java-tests/com/nvu/operacional/GtoMoneyValueRegressionTest.java",
  ],
);

const failed = checks.filter((x) => !x.ok);
console.log(`\n${checks.length - failed.length}/${checks.length} R3.35 surgical-flow checks passed.`);
if (failed.length) process.exit(1);
